#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 1.xaml / 2.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/BaseComponent.h>
#include <NsCore/ISerializable.h>
#include <NsCore/SerializationData.h>
#include <NsCore/UnserializationData.h>
#include <NsCore/String.h>
#include <NsCore/TypeId.h>

class DataModel1: public Noesis::Core::BaseComponent,
    public Noesis::Core::ISerializable
{
public:
    DataModel1(): _simpleText("default")
    {
    }

    ~DataModel1()
    {
    }

    const NsString& GetSimpleText() const
    {
        return _simpleText;
    }

    void SetSimpleText(const NsString& simpleText)
    {
        _simpleText = simpleText;
    }

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("SimpleText", _simpleText);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("SimpleText", _simpleText);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    NsString _simpleText;

    NS_IMPLEMENT_INLINE_REFLECTION(DataModel1, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("DataModel1");
        NsImpl<ISerializable>();

        NsProp("SimpleText", &DataModel1::GetSimpleText, &DataModel1::SetSimpleText);
    }
};


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 3.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/BaseComponent.h>
#include <NsCore/ISerializable.h>
#include <NsCore/SerializationData.h>
#include <NsCore/UnserializationData.h>
#include <NsCore/Symbol.h>
#include <NsCore/String.h>
#include <NsCore/TypeId.h>
#include <NsGui/INotifyPropertyChange.h>
#include <NsGui/UserControl.h>
#include <NsGui/ResourceDictionary.h>
#include <NsGui/UIElementData.h>
#include <NsGui/FrameworkPropertyMetadata.h>

NS_DECLARE_SYMBOL(SimpleText)

class DataModel2: public Noesis::Core::BaseComponent,
    public Noesis::Gui::INotifyPropertyChange,
    public Noesis::Core::ISerializable
{
public:
    DataModel2(): _simpleText("default")
    {
    }

    ~DataModel2()
    {
        _destroyedEvent(this);
    }

    const NsString& GetSimpleText() const
    {
        return _simpleText;
    }

    void SetSimpleText(const NsString& simpleText)
    {
        if (_simpleText != simpleText)
        {
            _simpleText = simpleText;
            _changedEvent(this, NSS(SimpleText));
        }
    }

    /// From INotifyPropertyChange
    //@{
    PropertyChangedEvent& PropertyChanged()
    {
        return _changedEvent;
    }

    DestroyedDelegate& Destroyed()
    {
        return _destroyedEvent;
    }
    //@}

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("SimpleText", _simpleText);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("SimpleText", _simpleText);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    NsString _simpleText;

    PropertyChangedEvent _changedEvent;
    DestroyedDelegate _destroyedEvent;

    NS_IMPLEMENT_INLINE_REFLECTION(DataModel2, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("DataModel2");
        NsImpl<INotifyPropertyChange>();
        NsImpl<ISerializable>();

        NsProp("SimpleText", &DataModel2::GetSimpleText, &DataModel2::SetSimpleText);
    }
};

struct MainPage1: public Noesis::Gui::UserControl
{
    void OnBtnClick(Noesis::Core::BaseComponent* sender,
        const Noesis::Gui::RoutedEventArgs& args)
    {
        DataModel2* dataModel = GetResources()->FindName<DataModel2>("dataModel");
        dataModel->SetSimpleText("bye bye");
    }

    NS_IMPLEMENT_INLINE_REFLECTION(MainPage1, UserControl)
    {
        NsMeta<Noesis::Core::TypeId>("MainPage1");

        NsFunc("OnBtnClick", &MainPage1::OnBtnClick);

        // this is the path to the xaml file that defines the MainPage content
        NsString source = "Gui/Tutorials/Bindings/MainPage.xaml";

        Noesis::Core::Ptr<Noesis::Gui::UIElementData> data =
            NsMeta<Noesis::Gui::UIElementData>(Noesis::Core::TypeOf<SelfClass>());

        data->OverrideMetadata<NsString>(UserControl::SourceProperty, "Source",
            Noesis::Gui::FrameworkPropertyMetadata::Create(source,
            Noesis::Gui::FrameworkOptions_None));
    }
};


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 4.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsGui/UserControl.h>
#include <NsGui/UIElementData.h>
#include <NsGui/FrameworkPropertyMetadata.h>

struct MainPage2: public Noesis::Gui::UserControl
{
    const NsString& GetLocalText() const
    {
        return GetValue<NsString>(LocalTextProperty);
    }

    void SetLocalText(const NsString& localText)
    {
        SetValue<NsString>(LocalTextProperty, localText);
    }

    static const Noesis::Gui::DependencyProperty* LocalTextProperty;

    NS_IMPLEMENT_INLINE_REFLECTION(MainPage2, UserControl)
    {
        NsMeta<Noesis::Core::TypeId>("MainPage2");

        // this is the path to the xaml file that defines the MainPage content
        NsString source = "Gui/Tutorials/Bindings/MainPage.xaml";

        Noesis::Core::Ptr<Noesis::Gui::UIElementData> data =
            NsMeta<Noesis::Gui::UIElementData>(Noesis::Core::TypeOf<SelfClass>());

        data->RegisterProperty<NsString>(LocalTextProperty, "LocalText",
            Noesis::Gui::FrameworkPropertyMetadata::Create(NsString("default"),
            Noesis::Gui::FrameworkOptions_None));
        data->OverrideMetadata<NsString>(UserControl::SourceProperty, "Source",
            Noesis::Gui::FrameworkPropertyMetadata::Create(source,
            Noesis::Gui::FrameworkOptions_None));
    }
};

const Noesis::Gui::DependencyProperty* MainPage2::LocalTextProperty;


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 6.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/BaseComponent.h>
#include <NsCore/ISerializable.h>
#include <NsCore/SerializationData.h>
#include <NsCore/UnserializationData.h>
#include <NsCore/TypeId.h>
#include <NsCore/String.h>

class PersonName: public Noesis::Core::BaseComponent,
    public Noesis::Core::ISerializable
{
    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("First", _first);
        data->Serialize("Last", _last);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("First", _first);
            data->Unserialize("Last", _last);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    NsString _first;
    NsString _last;

    NS_IMPLEMENT_INLINE_REFLECTION(PersonName, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("PersonName");
        NsImpl<ISerializable>();

        NsProp("First", &PersonName::_first);
        NsProp("Last", &PersonName::_last);
    }
};

class Person: public Noesis::Core::BaseComponent,
    public Noesis::Core::ISerializable
{
public:
    PersonName* GetFullName() const
    {
        return _fullName.GetPtr();
    }

    void SetFullName(PersonName* fullName)
    {
        _fullName.Reset(fullName);
    }

    NsFloat32 GetWeight() const
    {
        return _weight;
    }

    void SetWeight(NsFloat32 weight)
    {
        _weight = weight;
    }

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("FullName", _fullName);
        data->Serialize("Weight", _weight);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("FullName", _fullName);
            data->Unserialize("Weight", _weight);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    Noesis::Core::Ptr<PersonName> _fullName;
    NsFloat32 _weight;

    NS_IMPLEMENT_INLINE_REFLECTION(Person, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("Person");
        NsImpl<ISerializable>();

        NsProp("FullName", &Person::GetFullName, &Person::SetFullName);
        NsProp("Weight", &Person::GetWeight, &Person::SetWeight);
    }
};

class DataModel3: public Noesis::Core::BaseComponent,
    public Noesis::Core::ISerializable
{
public:
    const NsString& GetSimpleText() const
    {
        return _simpleText;
    }

    void SetSimpleText(const NsString& simpleText)
    {
        _simpleText = simpleText;
    }

    Person* GetPerson() const
    {
        return _person.GetPtr();
    }

    void SetPerson(Person* person)
    {
        _person.Reset(person);
    }

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("SimpleText", _simpleText);
        data->Serialize("Person", _person);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("SimpleText", _simpleText);
            data->Unserialize("Person", _person);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    NsString _simpleText;
    Noesis::Core::Ptr<Person> _person;

    NS_IMPLEMENT_INLINE_REFLECTION(DataModel3, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("DataModel3");
        NsImpl<ISerializable>();

        NsProp("SimpleText", &DataModel3::GetSimpleText, &DataModel3::SetSimpleText);
        NsProp("Person", &DataModel3::GetPerson, &DataModel3::SetPerson);
    }
};


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 8.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsGui/BaseValueConverter.h>
#include <NsCore/BoxingForward.h>
#include <NsCore/ParserExpr.h>
#include <NsCore/TypeId.h>
#include <NsCore/String.h>

class NumberValueConverter: public Noesis::Gui::BaseValueConverter
{
public:
    NumberValueConverter(): _precision(4)
    {
    }

    NsInt GetPrecision() const
    {
        return _precision;
    }

    void SetPrecision(NsInt precision)
    {
        _precision = precision;
    }

    NsBool TryConvert(BaseComponent* value, const Noesis::Core::Type* targetType,
        BaseComponent* parameter, Noesis::Core::Ptr<BaseComponent>& result)
    {
        Noesis::Core::Boxing::BoxedValueImpl<NsString>* boxed =
            NsDynamicCast<Noesis::Core::Boxing::BoxedValueImpl<NsString>*>(value);

        if (!boxed)
        {
            return false;
        }

        NsString& str = Noesis::Core::Boxing::Unbox<NsString>(boxed);

        NsFloat64 num = 0.0;
        if (!str.empty() && !TryParseNumber(str, num))
        {
            return false;
        }

        result = Noesis::Core::Boxing::Box<NsString>(NsString::Format("%.*f", _precision, num));

        return true;
    }

private:
    NsBool TryParseNumber(const NsString& str, NsFloat64& num)
    {
        Noesis::Core::PE::Float64 expr;
        Noesis::Core::Parser<> parser(str.c_str());

        if (parser.TryParse(expr))
        {
            parser.Skip();
            if (parser.End())
            {
                num = expr.number;
                return true;
            }
        }

        return false;
    }

private:
    NsInt _precision;

    NS_IMPLEMENT_INLINE_REFLECTION(NumberValueConverter, Noesis::Gui::BaseValueConverter)
    {
        NsMeta<Noesis::Core::TypeId>("NumberValueConverter");

        NsProp("Precision", &NumberValueConverter::_precision);
    }
};


////////////////////////////////////////////////////////////////////////////////////////////////////
#include <NsCore/Package.h>

extern "C" NS_DLL_EXPORT
void NsRegisterReflection(Noesis::Core::ComponentFactory* factory, NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(DataModel1)
    NS_REGISTER_COMPONENT(DataModel2)
    NS_REGISTER_COMPONENT(DataModel3)
    NS_REGISTER_COMPONENT(MainPage1)
    NS_REGISTER_COMPONENT(MainPage2)
    NS_REGISTER_COMPONENT(Person)
    NS_REGISTER_COMPONENT(PersonName)
    NS_REGISTER_COMPONENT(NumberValueConverter)
}