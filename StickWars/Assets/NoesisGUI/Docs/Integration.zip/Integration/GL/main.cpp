/* ============================================================================
**
** Demonstration of spinning cube
** Copyright (C) 2005  Julien Guertault
**
** This program is free software; you can redistribute it and/or
** modify it under the terms of the GNU General Public License
** as published by the Free Software Foundation; either version 2
** of the License, or (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
** ========================================================================= */

/* ============================================================================
** The original version of this sample was taken from:
**  http://www.lousodrome.net/opengl/
** ========================================================================= */

#define NOESIS_GUI

#include <stdlib.h>

#ifdef _MSC_VER
    #include <windows.h>
    #include <GL/gl.h>
    #include "glut.h"
#else
    #include <GLUT/glut.h>
#endif

#ifdef NOESIS_GUI

#ifdef _MSC_VER
    #pragma warning(disable: 4275)
    #pragma warning(disable: 4251)
#endif

#include <Noesis.h>
#include <NsCore/Kernel.h>
#include <NsCore/NsSystem.h>
#include <NsCore/NsConfig.h>
#include <NsGui/UIElement.h>
#include <NsGui/IRenderer.h>
#include <NsRender/IRenderSystem.h>

using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Gui;
using namespace Noesis::Render;
using namespace Noesis::Drawing;


Ptr<IRenderer> gXamlRenderer;

#ifdef _MSC_VER
    #define GL_FRAMEBUFFER 0x8D40

    typedef void (WINAPI *PFNGLBINDFRAMEBUFFERPROC)(GLenum target, GLuint framebuffer);
    PFNGLBINDFRAMEBUFFERPROC glBindFramebuffer;

    typedef void (WINAPI * PFNGLUSEPROGRAMPROC)(GLuint program);
    PFNGLUSEPROGRAMPROC glUseProgram;
#endif

#endif

/*
** Function called to update rendering
*/
void DisplayFunc(void)
{
#ifdef NOESIS_GUI
    // Tick kernel
    NsGetKernel()->Tick();

    // Update renderer
    gXamlRenderer->Update(glutGet(GLUT_ELAPSED_TIME) / 1000.0f);
    // ...Do something useful here because Update() is concurrent...
    RenderCommands commands = gXamlRenderer->WaitForUpdate();

    // Render offscreen
    gXamlRenderer->Render(commands.offscreenCommands.GetPtr());
#endif

    static float alpha = 0;

    glClearColor(0, 0, 0, 0);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
    glDepthFunc(GL_LESS);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glUseProgram(0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    /* Clear the buffer, clear the matrix */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    /* A step backward, then spin the cube */
    glTranslatef(0, 0, -10);
    glRotatef(30, 1, 0, 0);
    glRotatef(alpha, 0, 1, 0);

    /* We tell we want to draw quads */
    glBegin(GL_QUADS);

    /* Every four calls to glVertex, a quad is drawn */
    glColor3f(0, 0, 0); glVertex3f(-1, -1, -1);
    glColor3f(0, 0, 1); glVertex3f(-1, -1,  1);
    glColor3f(0, 1, 1); glVertex3f(-1,  1,  1);
    glColor3f(0, 1, 0); glVertex3f(-1,  1, -1);

    glColor3f(1, 0, 0); glVertex3f( 1, -1, -1);
    glColor3f(1, 0, 1); glVertex3f( 1, -1,  1);
    glColor3f(1, 1, 1); glVertex3f( 1,  1,  1);
    glColor3f(1, 1, 0); glVertex3f( 1,  1, -1);

    glColor3f(0, 0, 0); glVertex3f(-1, -1, -1);
    glColor3f(0, 0, 1); glVertex3f(-1, -1,  1);
    glColor3f(1, 0, 1); glVertex3f( 1, -1,  1);
    glColor3f(1, 0, 0); glVertex3f( 1, -1, -1);

    glColor3f(0, 1, 0); glVertex3f(-1,  1, -1);
    glColor3f(0, 1, 1); glVertex3f(-1,  1,  1);
    glColor3f(1, 1, 1); glVertex3f( 1,  1,  1);
    glColor3f(1, 1, 0); glVertex3f( 1,  1, -1);

    glColor3f(0, 0, 0); glVertex3f(-1, -1, -1);
    glColor3f(0, 1, 0); glVertex3f(-1,  1, -1);
    glColor3f(1, 1, 0); glVertex3f( 1,  1, -1);
    glColor3f(1, 0, 0); glVertex3f( 1, -1, -1);

    glColor3f(0, 0, 1); glVertex3f(-1, -1,  1);
    glColor3f(0, 1, 1); glVertex3f(-1,  1,  1);
    glColor3f(1, 1, 1); glVertex3f( 1,  1,  1);
    glColor3f(1, 0, 1); glVertex3f( 1, -1,  1);

    /* No more quads */
    glEnd();

    /* Rotate a bit more */
    alpha = alpha + 0.1;

#ifdef NOESIS_GUI
    // Render GUI
    gXamlRenderer->Render(commands.commands.GetPtr());
#endif

    /* End */
    glFlush();
    glutSwapBuffers();

    /* Update again and again */
    glutPostRedisplay();
}

/*
** Function called when the window is created or resized
*/
void ReshapeFunc(int width, int height)
{
    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();
    gluPerspective(20, width / (float) height, 5, 15);
    glViewport(0, 0, width, height);

    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();

#ifdef NOESIS_GUI
    gXamlRenderer->SetSize(width, height);
#endif
}

void MouseFunc(int button, int state, int x, int y)
{
#ifdef NOESIS_GUI
    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_UP)
        {
            gXamlRenderer->MouseButtonUp(x, y, MouseButton_Left);
        }
        else
        {
            gXamlRenderer->MouseButtonDown(x, y, MouseButton_Left);
        }
    }
#endif
}

void MouseMove(int x, int y)
{
#ifdef NOESIS_GUI
    gXamlRenderer->MouseMove(x, y);
#endif
}

#ifdef NOESIS_GUI
void ErrorHandler(const NsChar* filename, NsInt line, const NsChar* desc)
{
    printf("\nERROR: %s\n\n", desc);
    exit(1);
}

void Shutdown(void)
{
    // Free global resources and shutdown kernel
    gXamlRenderer.Reset();
    NsGetKernel()->Shutdown();
}
#endif

int main(int argc, char **argv)
{
    /* Creation of the window */
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Spinning cube");

#ifdef _MSC_VER
    glBindFramebuffer = (PFNGLBINDFRAMEBUFFERPROC)wglGetProcAddress("glBindFramebuffer");
    glUseProgram = (PFNGLUSEPROGRAMPROC)wglGetProcAddress("glUseProgram");
#endif

#ifdef NOESIS_GUI
    {
        // Install an error handler to catch any problem with NoesisGui
        Noesis::Core::SetErrorHandler(ErrorHandler);

        // Force the OpenGL renderer
        NsConfigValue("Render.RenderSystem", "Render", "GL");

        // Launch Noesis Kernel
        NsGetKernel()->Init();

        // Create a OpenGL context that will be used by NoesisGui.
        NsGetKernel()->InitSystems();

        // Create the UI renderer
        Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Tutorials/Integration/GL/UI.xaml");
        //Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Samples/tux.xaml");
        //Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Samples/Button.xaml");
        //Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Samples/Time.xaml");
        //Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Samples/CarHUD.xaml");
        //Ptr<UIElement> xaml = LoadXaml<UIElement>("Gui/Samples/Text.xaml");
        gXamlRenderer = CreateRenderer(xaml.GetPtr());
        gXamlRenderer->SetAntialiasingMode(Noesis::Gui::AntialiasingMode_PPAA);

        atexit(Shutdown);
    }
#endif

    /* Declaration of the callbacks */
    glutDisplayFunc(&DisplayFunc);
    glutReshapeFunc(&ReshapeFunc);
    glutMouseFunc(&MouseFunc);
    glutMotionFunc(&MouseMove);
    glutPassiveMotionFunc(&MouseMove);

    /* Loop */
    glutMainLoop();

    /* Never reached */
    return 0;
}

/* ========================================================================= */
