#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsCore/Boxing.h>
#include <NsCore/Package.h>
#include <NsCore/String.h>
#include <NsGui/BaseValueConverter.h>


using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Gui;
using namespace Noesis::Core::Boxing;


////////////////////////////////////////////////////////////////////////////////////////////////////
class UppercaseConverter: public BaseValueConverter
{
public:
    NsBool TryConvert(BaseComponent* value, const Type* targetType, BaseComponent* parameter,
        Ptr<BaseComponent>& result)
    {
        NsString text = Unbox<NsString>(NsStaticCast<BoxedValue*>(value));
        text.make_upper();
        result =  Box<NsString>(text);
        return true;
    }

private:
    NS_IMPLEMENT_INLINE_REFLECTION(UppercaseConverter, BaseValueConverter)
    {
        NsMeta<TypeId>("UppercaseConverter");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" NS_DLL_EXPORT
void NsRegisterReflection(ComponentFactory* factory, NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(UppercaseConverter)
}
