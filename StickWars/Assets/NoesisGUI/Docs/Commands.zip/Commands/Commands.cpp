#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 2.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/BaseComponent.h>
#include <NsCore/ISerializable.h>
#include <NsCore/SerializationData.h>
#include <NsCore/UnserializationData.h>
#include <NsCore/Delegate.h>
#include <NsCore/Symbol.h>
#include <NsCore/String.h>
#include <NsCore/TypeId.h>
#include <NsGui/BaseCommand.h>
#include <NsGui/INotifyPropertyChange.h>

class DelegateCommand: public Noesis::Gui::BaseCommand
{
public:
    typedef Noesis::Core::Delegate<void ()> ActionDelegate;

    DelegateCommand(const ActionDelegate& action): BaseCommand(NsSymbol::Null(), 0),
        _action(action)
    {
    }

    /// From ICommand
    //@{
    NsBool CanExecute(BaseComponent* param) const
    {
        return true;
    }

    void Execute(BaseComponent* param) const
    {
        _action();
    }
    //@}

private:
    ActionDelegate _action;

    NS_IMPLEMENT_INLINE_REFLECTION(DelegateCommand, BaseCommand)
    {
        NsMeta<Noesis::Core::TypeId>("DelegateCommand");
    }
};

NS_DECLARE_SYMBOL(Output)

class ViewModel: public Noesis::Core::BaseComponent,
    public Noesis::Gui::INotifyPropertyChange,
    public Noesis::Core::ISerializable
{
public:
    ViewModel()
    {
        _command = *new DelegateCommand(MakeDelegate(this, &ViewModel::SayHello));
    }

    ~ViewModel()
    {
        _destroyedEvent(this);
    }

    const NsString& GetInput() const
    {
        return _input;
    }

    void SetInput(const NsString& input)
    {
        _input = input;
    }

    const NsString& GetOutput() const
    {
        return _output;
    }

    void SetOutput(const NsString& output)
    {
        if (_output != output)
        {
            _output = output;
            _changedEvent(this, NSS(Output));
        }
    }

    const Noesis::Core::Ptr<DelegateCommand>& GetSayHelloCommand() const
    {
        return _command;
    }

    /// From INotifyPropertyChange
    //@{
    PropertyChangedEvent& PropertyChanged()
    {
        return _changedEvent;
    }

    DestroyedDelegate& Destroyed()
    {
        return _destroyedEvent;
    }
    //@}

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("Input", _input);
        data->Serialize("Output", _output);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("Input", _input);
            data->Unserialize("Output", _output);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }

    void PostUnserialize()
    {
    }
    //@}

private:
    void SayHello()
    {
        SetOutput(NsString::Format("Hello, %s", _input));
    }

private:
    Noesis::Core::Ptr<DelegateCommand> _command;

    NsString _input;
    NsString _output;

    PropertyChangedEvent _changedEvent;
    DestroyedDelegate _destroyedEvent;

    NS_IMPLEMENT_INLINE_REFLECTION(ViewModel, BaseComponent)
    {
        NsMeta<Noesis::Core::TypeId>("ViewModel");
        NsImpl<INotifyPropertyChange>();
        NsImpl<ISerializable>();

        NsProp("Input", &ViewModel::GetInput, &ViewModel::SetInput);
        NsProp("Output", &ViewModel::GetOutput, &ViewModel::SetOutput);
        NsProp("SayHelloCommand", &ViewModel::GetSayHelloCommand);
    }
};


////////////////////////////////////////////////////////////////////////////////////////////////////
/// 3.xaml
////////////////////////////////////////////////////////////////////////////////////////////////////
#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/BaseComponent.h>
#include <NsCore/ISerializable.h>
#include <NsCore/SerializationData.h>
#include <NsCore/UnserializationData.h>
#include <NsCore/Delegate.h>
#include <NsCore/Symbol.h>
#include <NsCore/String.h>
#include <NsCore/TypeId.h>
#include <NsGui/INotifyPropertyChange.h>

class BaseViewModel: public Noesis::Core::BaseComponent,
    public Noesis::Gui::INotifyPropertyChange,
    public Noesis::Core::ISerializable
{
public:
    BaseViewModel()
    {
    }

    ~BaseViewModel()
    {
        _destroyedEvent(this);
    }

    /// From INotifyPropertyChanged
    //@{
    PropertyChangedEvent& PropertyChanged()
    {
        return _changedEvent;
    }

    DestroyedDelegate& Destroyed()
    {
        return _destroyedEvent;
    }
    //@}

    /// From ISerializable
    //@{
    NsUInt32 GetVersion() const
    {
        return 0;
    }

    void Serialize(Noesis::Core::SerializationData* data) const
    {
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
    }

    void PostUnserialize()
    {
    }
    //@}

protected:
    virtual void OnPropertyChanged(NsSymbol propName)
    {
        _changedEvent(this, propName);
    }

private:
    PropertyChangedEvent _changedEvent;
    DestroyedDelegate _destroyedEvent;

    NS_IMPLEMENT_INLINE_REFLECTION(BaseViewModel, BaseComponent)
    {
        NsImpl<INotifyPropertyChange>();
        NsImpl<ISerializable>();
    }
};

//NS_DECLARE_SYMBOL(Output)

class ViewModel2: public BaseViewModel
{
public:
    ViewModel2()
    {
        _command = *new DelegateCommand(MakeDelegate(this, &ViewModel2::SayHello));
    }

    ~ViewModel2()
    {
    }

    const NsString& GetInput() const
    {
        return _input;
    }

    void SetInput(const NsString& input)
    {
        _input = input;
    }

    const NsString& GetOutput() const
    {
        return _output;
    }

    void SetOutput(const NsString& output)
    {
        if (_output != output)
        {
            _output = output;
            OnPropertyChanged(NSS(Output));
        }
    }

    const Noesis::Core::Ptr<DelegateCommand>& GetSayHelloCommand() const
    {
        return _command;
    }

    /// From ISerializable
    //@{
    void Serialize(Noesis::Core::SerializationData* data) const
    {
        data->Serialize("Input", _input);
        data->Serialize("Output", _output);
    }

    void Unserialize(Noesis::Core::UnserializationData* data, NsUInt32 version)
    {
        if (version == 0)
        {
            data->Unserialize("Input", _input);
            data->Unserialize("Output", _output);
        }
        else
        {
            NS_ERROR("Unknown version %u", version);
        }
    }
    //@}

private:
    void SayHello()
    {
        SetOutput(NsString::Format("Hello, %s", _input));
    }

private:
    Noesis::Core::Ptr<DelegateCommand> _command;

    NsString _input;
    NsString _output;

    NS_IMPLEMENT_INLINE_REFLECTION(ViewModel2, BaseViewModel)
    {
        NsMeta<Noesis::Core::TypeId>("ViewModel2");

        NsProp("Input", &ViewModel2::GetInput, &ViewModel2::SetInput);
        NsProp("Output", &ViewModel2::GetOutput, &ViewModel2::SetOutput);
        NsProp("SayHelloCommand", &ViewModel2::GetSayHelloCommand);
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
#include <NsCore/Package.h>

extern "C" NS_DLL_EXPORT
void NsRegisterReflection(Noesis::Core::ComponentFactory* factory, NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(ViewModel)
    NS_REGISTER_COMPONENT(ViewModel2)
}